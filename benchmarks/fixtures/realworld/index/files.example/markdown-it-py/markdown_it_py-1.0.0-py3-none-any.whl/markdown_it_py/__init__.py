# markdown-it-py 1.0.0
VERSION = "1.0.0"
