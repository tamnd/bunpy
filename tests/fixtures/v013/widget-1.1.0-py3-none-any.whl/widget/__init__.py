def hello():
    return "widget 1.1.0"
