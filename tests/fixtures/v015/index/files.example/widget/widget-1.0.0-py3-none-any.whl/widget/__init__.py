from gizmo import gear

def hello():
    return f"widget 1.0.0 + {gear()}"
