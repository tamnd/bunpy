def hello():
    return "widget 1.0.0"
